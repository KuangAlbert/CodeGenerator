
1. IMPORTANT! Use libxl.dll from stdcall folder!
2. Put libxl.dll near .exe (or near vb6.exe for debug) or to the folder listed in PATH enviroment variable.

