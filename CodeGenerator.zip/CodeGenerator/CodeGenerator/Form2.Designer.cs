﻿namespace CodeGenerator
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader21 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader22 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.label43 = new System.Windows.Forms.Label();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.button5 = new System.Windows.Forms.Button();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.label41 = new System.Windows.Forms.Label();
            this.comboBox15 = new System.Windows.Forms.ComboBox();
            this.label47 = new System.Windows.Forms.Label();
            this.comboBox16 = new System.Windows.Forms.ComboBox();
            this.label48 = new System.Windows.Forms.Label();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label45 = new System.Windows.Forms.Label();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.label39 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.linkLabel12 = new System.Windows.Forms.LinkLabel();
            this.label59 = new System.Windows.Forms.Label();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.linkLabel84 = new System.Windows.Forms.LinkLabel();
            this.label32 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader23 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.checkBox33 = new System.Windows.Forms.CheckBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.checkBox34 = new System.Windows.Forms.CheckBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.checkBox31 = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkBox28 = new System.Windows.Forms.CheckBox();
            this.checkBox27 = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox26 = new System.Windows.Forms.CheckBox();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.checkBox32 = new System.Windows.Forms.CheckBox();
            this.label22 = new System.Windows.Forms.Label();
            this.checkBox35 = new System.Windows.Forms.CheckBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label31 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.label17 = new System.Windows.Forms.Label();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.label15 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.linkLabel63 = new System.Windows.Forms.LinkLabel();
            this.linkLabel40 = new System.Windows.Forms.LinkLabel();
            this.linkLabel49 = new System.Windows.Forms.LinkLabel();
            this.linkLabel50 = new System.Windows.Forms.LinkLabel();
            this.linkLabel51 = new System.Windows.Forms.LinkLabel();
            this.linkLabel52 = new System.Windows.Forms.LinkLabel();
            this.linkLabel59 = new System.Windows.Forms.LinkLabel();
            this.linkLabel60 = new System.Windows.Forms.LinkLabel();
            this.linkLabel61 = new System.Windows.Forms.LinkLabel();
            this.linkLabel47 = new System.Windows.Forms.LinkLabel();
            this.linkLabel66 = new System.Windows.Forms.LinkLabel();
            this.linkLabel34 = new System.Windows.Forms.LinkLabel();
            this.linkLabel35 = new System.Windows.Forms.LinkLabel();
            this.linkLabel36 = new System.Windows.Forms.LinkLabel();
            this.linkLabel37 = new System.Windows.Forms.LinkLabel();
            this.linkLabel38 = new System.Windows.Forms.LinkLabel();
            this.linkLabel39 = new System.Windows.Forms.LinkLabel();
            this.linkLabel46 = new System.Windows.Forms.LinkLabel();
            this.linkLabel44 = new System.Windows.Forms.LinkLabel();
            this.linkLabel43 = new System.Windows.Forms.LinkLabel();
            this.linkLabel33 = new System.Windows.Forms.LinkLabel();
            this.linkLabel17 = new System.Windows.Forms.LinkLabel();
            this.linkLabel20 = new System.Windows.Forms.LinkLabel();
            this.linkLabel21 = new System.Windows.Forms.LinkLabel();
            this.linkLabel22 = new System.Windows.Forms.LinkLabel();
            this.linkLabel23 = new System.Windows.Forms.LinkLabel();
            this.linkLabel24 = new System.Windows.Forms.LinkLabel();
            this.linkLabel25 = new System.Windows.Forms.LinkLabel();
            this.linkLabel26 = new System.Windows.Forms.LinkLabel();
            this.linkLabel27 = new System.Windows.Forms.LinkLabel();
            this.linkLabel28 = new System.Windows.Forms.LinkLabel();
            this.linkLabel29 = new System.Windows.Forms.LinkLabel();
            this.linkLabel30 = new System.Windows.Forms.LinkLabel();
            this.linkLabel31 = new System.Windows.Forms.LinkLabel();
            this.linkLabel32 = new System.Windows.Forms.LinkLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.linkLabel16 = new System.Windows.Forms.LinkLabel();
            this.linkLabel15 = new System.Windows.Forms.LinkLabel();
            this.linkLabel14 = new System.Windows.Forms.LinkLabel();
            this.linkLabel13 = new System.Windows.Forms.LinkLabel();
            this.linkLabel11 = new System.Windows.Forms.LinkLabel();
            this.linkLabel10 = new System.Windows.Forms.LinkLabel();
            this.linkLabel9 = new System.Windows.Forms.LinkLabel();
            this.linkLabel8 = new System.Windows.Forms.LinkLabel();
            this.linkLabel7 = new System.Windows.Forms.LinkLabel();
            this.linkLabel6 = new System.Windows.Forms.LinkLabel();
            this.linkLabel5 = new System.Windows.Forms.LinkLabel();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage3.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tabPage3.Controls.Add(this.groupBox17);
            this.tabPage3.Controls.Add(this.listView2);
            this.tabPage3.Controls.Add(this.groupBox13);
            this.tabPage3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.tabPage3.Location = new System.Drawing.Point(4, 26);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage3.Size = new System.Drawing.Size(1192, 765);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = " Peripheral";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.textBox21);
            this.groupBox17.Controls.Add(this.textBox20);
            this.groupBox17.Controls.Add(this.textBox19);
            this.groupBox17.Controls.Add(this.textBox18);
            this.groupBox17.Controls.Add(this.textBox17);
            this.groupBox17.Controls.Add(this.textBox16);
            this.groupBox17.Controls.Add(this.textBox15);
            this.groupBox17.Controls.Add(this.textBox22);
            this.groupBox17.Controls.Add(this.textBox14);
            this.groupBox17.Controls.Add(this.textBox13);
            this.groupBox17.Controls.Add(this.textBox12);
            this.groupBox17.Controls.Add(this.label9);
            this.groupBox17.Controls.Add(this.label10);
            this.groupBox17.Controls.Add(this.label11);
            this.groupBox17.Controls.Add(this.label16);
            this.groupBox17.Controls.Add(this.label23);
            this.groupBox17.Controls.Add(this.label24);
            this.groupBox17.Controls.Add(this.label25);
            this.groupBox17.Controls.Add(this.label26);
            this.groupBox17.Controls.Add(this.label27);
            this.groupBox17.Controls.Add(this.label28);
            this.groupBox17.Controls.Add(this.label29);
            this.groupBox17.Location = new System.Drawing.Point(3, 310);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(1182, 339);
            this.groupBox17.TabIndex = 297;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "All Add Interrupt";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(855, 144);
            this.textBox21.Multiline = true;
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(320, 80);
            this.textBox21.TabIndex = 329;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(428, 144);
            this.textBox20.Multiline = true;
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(320, 80);
            this.textBox20.TabIndex = 328;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(59, 144);
            this.textBox19.Multiline = true;
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(320, 80);
            this.textBox19.TabIndex = 327;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(45, 230);
            this.textBox18.Multiline = true;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(510, 103);
            this.textBox18.TabIndex = 326;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(855, 58);
            this.textBox17.Multiline = true;
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(320, 80);
            this.textBox17.TabIndex = 325;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(428, 58);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(320, 80);
            this.textBox16.TabIndex = 324;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(59, 58);
            this.textBox15.Multiline = true;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(320, 80);
            this.textBox15.TabIndex = 323;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(664, 230);
            this.textBox22.Multiline = true;
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(510, 101);
            this.textBox22.TabIndex = 322;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(854, 22);
            this.textBox14.Multiline = true;
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(320, 30);
            this.textBox14.TabIndex = 314;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(428, 22);
            this.textBox13.Multiline = true;
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(320, 30);
            this.textBox13.TabIndex = 313;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(59, 22);
            this.textBox12.Multiline = true;
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(320, 30);
            this.textBox12.TabIndex = 312;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(2, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 17);
            this.label9.TabIndex = 305;
            this.label9.Text = "OSTimer:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(23, 176);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 17);
            this.label10.TabIndex = 301;
            this.label10.Text = "DMA:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(785, 25);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 17);
            this.label11.TabIndex = 309;
            this.label11.Text = "WatchDog:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(391, 91);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(38, 17);
            this.label16.TabIndex = 311;
            this.label16.Text = "SPIH:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 280);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(42, 17);
            this.label23.TabIndex = 307;
            this.label23.Text = "PWM:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(746, 176);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(111, 17);
            this.label24.TabIndex = 299;
            this.label24.Text = "External interrupt:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(555, 280);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(106, 17);
            this.label25.TabIndex = 290;
            this.label25.Text = "Timer Array Unit:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(380, 25);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(51, 17);
            this.label26.TabIndex = 293;
            this.label26.Text = "ADCA0:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(402, 176);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(27, 17);
            this.label27.TabIndex = 303;
            this.label27.Text = "IIC:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(26, 91);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(37, 17);
            this.label28.TabIndex = 295;
            this.label28.Text = "CAN:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(781, 91);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(76, 17);
            this.label29.TabIndex = 297;
            this.label29.Text = "RLIN/UART:";
            // 
            // listView2
            // 
            this.listView2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15,
            this.columnHeader16,
            this.columnHeader17,
            this.columnHeader18,
            this.columnHeader19,
            this.columnHeader20,
            this.columnHeader21,
            this.columnHeader22});
            this.listView2.GridLines = true;
            this.listView2.Location = new System.Drawing.Point(0, 657);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(1188, 108);
            this.listView2.TabIndex = 295;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "OSTimer";
            this.columnHeader12.Width = 85;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "ADC";
            this.columnHeader13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader13.Width = 110;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "CAN";
            this.columnHeader14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader14.Width = 110;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "IIC";
            this.columnHeader15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader15.Width = 110;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "PWM";
            this.columnHeader16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader16.Width = 110;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "DMA";
            this.columnHeader17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader17.Width = 110;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "EX_int";
            this.columnHeader18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader18.Width = 110;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "TAU";
            this.columnHeader19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader19.Width = 110;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "UART";
            this.columnHeader20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader20.Width = 110;
            // 
            // columnHeader21
            // 
            this.columnHeader21.Text = "SPI";
            this.columnHeader21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader21.Width = 110;
            // 
            // columnHeader22
            // 
            this.columnHeader22.Text = "WatchDog";
            this.columnHeader22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader22.Width = 120;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.richTextBox2);
            this.groupBox13.Controls.Add(this.comboBox13);
            this.groupBox13.Controls.Add(this.label43);
            this.groupBox13.Controls.Add(this.comboBox10);
            this.groupBox13.Controls.Add(this.button5);
            this.groupBox13.Controls.Add(this.comboBox11);
            this.groupBox13.Controls.Add(this.label41);
            this.groupBox13.Controls.Add(this.comboBox15);
            this.groupBox13.Controls.Add(this.label47);
            this.groupBox13.Controls.Add(this.comboBox16);
            this.groupBox13.Controls.Add(this.label48);
            this.groupBox13.Controls.Add(this.comboBox14);
            this.groupBox13.Controls.Add(this.label46);
            this.groupBox13.Controls.Add(this.label40);
            this.groupBox13.Controls.Add(this.comboBox5);
            this.groupBox13.Controls.Add(this.label45);
            this.groupBox13.Controls.Add(this.comboBox7);
            this.groupBox13.Controls.Add(this.label37);
            this.groupBox13.Controls.Add(this.comboBox8);
            this.groupBox13.Controls.Add(this.comboBox12);
            this.groupBox13.Controls.Add(this.label42);
            this.groupBox13.Controls.Add(this.label38);
            this.groupBox13.Controls.Add(this.comboBox9);
            this.groupBox13.Controls.Add(this.label39);
            this.groupBox13.Location = new System.Drawing.Point(3, 7);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(1179, 299);
            this.groupBox13.TabIndex = 294;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Interrupt";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(2, 80);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(1171, 213);
            this.richTextBox2.TabIndex = 290;
            this.richTextBox2.Text = "";
            // 
            // comboBox13
            // 
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.Items.AddRange(new object[] {
            "0"});
            this.comboBox13.Location = new System.Drawing.Point(84, 17);
            this.comboBox13.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(85, 25);
            this.comboBox13.TabIndex = 283;
            this.comboBox13.SelectedIndexChanged += new System.EventHandler(this.comboBox13_SelectedIndexChanged_1);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(15, 20);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(61, 17);
            this.label43.TabIndex = 282;
            this.label43.Text = "OSTimer:";
            // 
            // comboBox10
            // 
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "10",
            "11",
            "12"});
            this.comboBox10.Location = new System.Drawing.Point(637, 14);
            this.comboBox10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(85, 25);
            this.comboBox10.TabIndex = 277;
            this.comboBox10.SelectedIndexChanged += new System.EventHandler(this.comboBox10_SelectedIndexChanged_1);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(1002, 46);
            this.button5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(171, 27);
            this.button5.TabIndex = 267;
            this.button5.Text = "SAVE";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // comboBox11
            // 
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.comboBox11.Location = new System.Drawing.Point(637, 50);
            this.comboBox11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(85, 25);
            this.comboBox11.TabIndex = 279;
            this.comboBox11.SelectedIndexChanged += new System.EventHandler(this.comboBox11_SelectedIndexChanged_1);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(594, 52);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(40, 17);
            this.label41.TabIndex = 278;
            this.label41.Text = "DMA:";
            // 
            // comboBox15
            // 
            this.comboBox15.FormattingEnabled = true;
            this.comboBox15.Items.AddRange(new object[] {
            "0",
            "1"});
            this.comboBox15.Location = new System.Drawing.Point(855, 48);
            this.comboBox15.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox15.Name = "comboBox15";
            this.comboBox15.Size = new System.Drawing.Size(85, 25);
            this.comboBox15.TabIndex = 287;
            this.comboBox15.SelectedIndexChanged += new System.EventHandler(this.comboBox15_SelectedIndexChanged_1);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(781, 51);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(72, 17);
            this.label47.TabIndex = 286;
            this.label47.Text = "WatchDog:";
            // 
            // comboBox16
            // 
            this.comboBox16.FormattingEnabled = true;
            this.comboBox16.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.comboBox16.Location = new System.Drawing.Point(405, 17);
            this.comboBox16.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox16.Name = "comboBox16";
            this.comboBox16.Size = new System.Drawing.Size(85, 25);
            this.comboBox16.TabIndex = 289;
            this.comboBox16.SelectedIndexChanged += new System.EventHandler(this.comboBox16_SelectedIndexChanged_1);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(361, 20);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(38, 17);
            this.label48.TabIndex = 288;
            this.label48.Text = "SPIH:";
            // 
            // comboBox14
            // 
            this.comboBox14.FormattingEnabled = true;
            this.comboBox14.Items.AddRange(new object[] {
            "0",
            "1",
            "2 ",
            "3",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "27",
            "28",
            "29",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47"});
            this.comboBox14.Location = new System.Drawing.Point(855, 12);
            this.comboBox14.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox14.Name = "comboBox14";
            this.comboBox14.Size = new System.Drawing.Size(85, 25);
            this.comboBox14.TabIndex = 285;
            this.comboBox14.SelectedIndexChanged += new System.EventHandler(this.comboBox14_SelectedIndexChanged_1);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(809, 15);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(42, 17);
            this.label46.TabIndex = 284;
            this.label46.Text = "PWM:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(520, 17);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(111, 17);
            this.label40.TabIndex = 276;
            this.label40.Text = "External interrupt:";
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "B0_0",
            "B0_1",
            "B0_2",
            "B0_3",
            "B0_4",
            "B0_5",
            "B0_6",
            "B0_7",
            "B0_8",
            "B0_9",
            "B0_10",
            "B0_11",
            "B0_12",
            "B0_13",
            "B0_14",
            "B0_15",
            "D0_0",
            "D0_1",
            "D0_2",
            "D0_3",
            "D0_4",
            "D0_5",
            "D0_6",
            "D0_7",
            "D0_8",
            "D0_9",
            "D0_10",
            "D0_11",
            "D0_12",
            "D0_13",
            "D0_14",
            "D0_15",
            "J0_0",
            "J0_1",
            "J0_2",
            "J0_3",
            "J1_0",
            "J1_1",
            "J1_2",
            "J1_3"});
            this.comboBox5.Location = new System.Drawing.Point(125, 49);
            this.comboBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(85, 25);
            this.comboBox5.TabIndex = 266;
            this.comboBox5.SelectedIndexChanged += new System.EventHandler(this.comboBox5_SelectedIndexChanged_1);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(15, 52);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(106, 17);
            this.label45.TabIndex = 265;
            this.label45.Text = "Timer Array Unit:";
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "0",
            "1",
            "2"});
            this.comboBox7.Location = new System.Drawing.Point(1074, 13);
            this.comboBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(85, 25);
            this.comboBox7.TabIndex = 271;
            this.comboBox7.SelectedIndexChanged += new System.EventHandler(this.comboBox7_SelectedIndexChanged_1);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(999, 16);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(51, 17);
            this.label37.TabIndex = 270;
            this.label37.Text = "ADCA0:";
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "0",
            "1",
            "2"});
            this.comboBox8.Location = new System.Drawing.Point(282, 49);
            this.comboBox8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(85, 25);
            this.comboBox8.TabIndex = 273;
            this.comboBox8.SelectedIndexChanged += new System.EventHandler(this.comboBox8_SelectedIndexChanged_1);
            // 
            // comboBox12
            // 
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Items.AddRange(new object[] {
            "0"});
            this.comboBox12.Location = new System.Drawing.Point(242, 17);
            this.comboBox12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(85, 25);
            this.comboBox12.TabIndex = 281;
            this.comboBox12.SelectedIndexChanged += new System.EventHandler(this.comboBox12_SelectedIndexChanged_1);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(209, 20);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(27, 17);
            this.label42.TabIndex = 280;
            this.label42.Text = "IIC:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(239, 52);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(37, 17);
            this.label38.TabIndex = 272;
            this.label38.Text = "CAN:";
            // 
            // comboBox9
            // 
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "0",
            "1",
            "2"});
            this.comboBox9.Location = new System.Drawing.Point(484, 50);
            this.comboBox9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(85, 25);
            this.comboBox9.TabIndex = 275;
            this.comboBox9.SelectedIndexChanged += new System.EventHandler(this.comboBox9_SelectedIndexChanged_1);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(402, 52);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(76, 17);
            this.label39.TabIndex = 274;
            this.label39.Text = "RLIN/UART:";
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tabPage1.Controls.Add(this.groupBox18);
            this.tabPage1.Controls.Add(this.groupBox16);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Location = new System.Drawing.Point(4, 26);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Size = new System.Drawing.Size(1192, 765);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "SystemEnable";
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.linkLabel12);
            this.groupBox18.Controls.Add(this.label59);
            this.groupBox18.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox18.Location = new System.Drawing.Point(579, 347);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(571, 327);
            this.groupBox18.TabIndex = 8;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Code Generator Introduction";
            // 
            // linkLabel12
            // 
            this.linkLabel12.AutoSize = true;
            this.linkLabel12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel12.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.linkLabel12.Location = new System.Drawing.Point(416, 294);
            this.linkLabel12.Name = "linkLabel12";
            this.linkLabel12.Size = new System.Drawing.Size(134, 21);
            this.linkLabel12.TabIndex = 3;
            this.linkLabel12.TabStop = true;
            this.linkLabel12.Text = "Show More Info";
            this.linkLabel12.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel12_LinkClicked_1);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label59.Location = new System.Drawing.Point(18, 49);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(532, 231);
            this.label59.TabIndex = 0;
            this.label59.Text = resources.GetString("label59.Text");
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.linkLabel84);
            this.groupBox16.Controls.Add(this.label32);
            this.groupBox16.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox16.Location = new System.Drawing.Point(43, 90);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(651, 176);
            this.groupBox16.TabIndex = 7;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "RH850/F1L Group Introduction";
            // 
            // linkLabel84
            // 
            this.linkLabel84.AutoSize = true;
            this.linkLabel84.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel84.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.linkLabel84.Location = new System.Drawing.Point(501, 141);
            this.linkLabel84.Name = "linkLabel84";
            this.linkLabel84.Size = new System.Drawing.Size(134, 21);
            this.linkLabel84.TabIndex = 2;
            this.linkLabel84.TabStop = true;
            this.linkLabel84.Text = "Show More Info";
            this.linkLabel84.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel84_LinkClicked);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label32.Location = new System.Drawing.Point(18, 46);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(597, 84);
            this.label32.TabIndex = 0;
            this.label32.Text = resources.GetString("label32.Text");
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(933, 614);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(154, 34);
            this.button2.TabIndex = 6;
            this.button2.Text = "Start Configuration";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabControl1.Location = new System.Drawing.Point(-3, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1200, 795);
            this.tabControl1.TabIndex = 13;
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tabPage7.Controls.Add(this.listView1);
            this.tabPage7.Controls.Add(this.label1);
            this.tabPage7.Controls.Add(this.textBox11);
            this.tabPage7.Controls.Add(this.panel1);
            this.tabPage7.Controls.Add(this.label58);
            this.tabPage7.Controls.Add(this.label57);
            this.tabPage7.Controls.Add(this.label56);
            this.tabPage7.Controls.Add(this.label55);
            this.tabPage7.Controls.Add(this.label54);
            this.tabPage7.Controls.Add(this.label53);
            this.tabPage7.Controls.Add(this.label52);
            this.tabPage7.Controls.Add(this.label51);
            this.tabPage7.Controls.Add(this.label50);
            this.tabPage7.Controls.Add(this.label49);
            this.tabPage7.Controls.Add(this.label44);
            this.tabPage7.Controls.Add(this.label30);
            this.tabPage7.Controls.Add(this.label14);
            this.tabPage7.Controls.Add(this.label7);
            this.tabPage7.Controls.Add(this.linkLabel63);
            this.tabPage7.Controls.Add(this.linkLabel40);
            this.tabPage7.Controls.Add(this.linkLabel49);
            this.tabPage7.Controls.Add(this.linkLabel50);
            this.tabPage7.Controls.Add(this.linkLabel51);
            this.tabPage7.Controls.Add(this.linkLabel52);
            this.tabPage7.Controls.Add(this.linkLabel59);
            this.tabPage7.Controls.Add(this.linkLabel60);
            this.tabPage7.Controls.Add(this.linkLabel61);
            this.tabPage7.Controls.Add(this.linkLabel47);
            this.tabPage7.Controls.Add(this.linkLabel66);
            this.tabPage7.Controls.Add(this.linkLabel34);
            this.tabPage7.Controls.Add(this.linkLabel35);
            this.tabPage7.Controls.Add(this.linkLabel36);
            this.tabPage7.Controls.Add(this.linkLabel37);
            this.tabPage7.Controls.Add(this.linkLabel38);
            this.tabPage7.Controls.Add(this.linkLabel39);
            this.tabPage7.Controls.Add(this.linkLabel46);
            this.tabPage7.Controls.Add(this.linkLabel44);
            this.tabPage7.Controls.Add(this.linkLabel43);
            this.tabPage7.Controls.Add(this.linkLabel33);
            this.tabPage7.Controls.Add(this.linkLabel17);
            this.tabPage7.Controls.Add(this.linkLabel20);
            this.tabPage7.Controls.Add(this.linkLabel21);
            this.tabPage7.Controls.Add(this.linkLabel22);
            this.tabPage7.Controls.Add(this.linkLabel23);
            this.tabPage7.Controls.Add(this.linkLabel24);
            this.tabPage7.Controls.Add(this.linkLabel25);
            this.tabPage7.Controls.Add(this.linkLabel26);
            this.tabPage7.Controls.Add(this.linkLabel27);
            this.tabPage7.Controls.Add(this.linkLabel28);
            this.tabPage7.Controls.Add(this.linkLabel29);
            this.tabPage7.Controls.Add(this.linkLabel30);
            this.tabPage7.Controls.Add(this.linkLabel31);
            this.tabPage7.Controls.Add(this.linkLabel32);
            this.tabPage7.Controls.Add(this.pictureBox1);
            this.tabPage7.Controls.Add(this.linkLabel16);
            this.tabPage7.Controls.Add(this.linkLabel15);
            this.tabPage7.Controls.Add(this.linkLabel14);
            this.tabPage7.Controls.Add(this.linkLabel13);
            this.tabPage7.Controls.Add(this.linkLabel11);
            this.tabPage7.Controls.Add(this.linkLabel10);
            this.tabPage7.Controls.Add(this.linkLabel9);
            this.tabPage7.Controls.Add(this.linkLabel8);
            this.tabPage7.Controls.Add(this.linkLabel7);
            this.tabPage7.Controls.Add(this.linkLabel6);
            this.tabPage7.Controls.Add(this.linkLabel5);
            this.tabPage7.Controls.Add(this.linkLabel4);
            this.tabPage7.Controls.Add(this.linkLabel3);
            this.tabPage7.Controls.Add(this.linkLabel2);
            this.tabPage7.Controls.Add(this.linkLabel1);
            this.tabPage7.Location = new System.Drawing.Point(4, 26);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1192, 765);
            this.tabPage7.TabIndex = 3;
            this.tabPage7.Text = "  I/O";
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader23});
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.HoverSelection = true;
            this.listView1.Location = new System.Drawing.Point(0, 633);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(1194, 151);
            this.listView1.TabIndex = 340;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Port";
            this.columnHeader1.Width = 84;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Mode";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 91;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Alt&GPIO";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 91;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Function";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader4.Width = 113;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "In&Out";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader5.Width = 78;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "InputBuffer";
            this.columnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader6.Width = 98;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Pull-up Res";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader7.Width = 108;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Pull-down Res";
            this.columnHeader8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader8.Width = 114;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Bid Mode";
            this.columnHeader9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader9.Width = 103;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Diver Strength";
            this.columnHeader10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader10.Width = 113;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Output Mode";
            this.columnHeader11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader11.Width = 105;
            // 
            // columnHeader23
            // 
            this.columnHeader23.Text = "Port Value";
            this.columnHeader23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader23.Width = 93;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 17);
            this.label1.TabIndex = 266;
            this.label1.Text = "Project Path:";
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.Color.White;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox11.Location = new System.Drawing.Point(85, 15);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(441, 16);
            this.textBox11.TabIndex = 264;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBox23);
            this.panel1.Controls.Add(this.checkBox33);
            this.panel1.Controls.Add(this.groupBox12);
            this.panel1.Controls.Add(this.checkBox34);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.checkBox35);
            this.panel1.Controls.Add(this.groupBox9);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(655, 9);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(518, 621);
            this.panel1.TabIndex = 262;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(82, 7);
            this.textBox23.Multiline = true;
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(100, 21);
            this.textBox23.TabIndex = 266;
            // 
            // checkBox33
            // 
            this.checkBox33.AutoSize = true;
            this.checkBox33.ForeColor = System.Drawing.Color.Black;
            this.checkBox33.Location = new System.Drawing.Point(202, 44);
            this.checkBox33.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox33.Name = "checkBox33";
            this.checkBox33.Size = new System.Drawing.Size(83, 21);
            this.checkBox33.TabIndex = 261;
            this.checkBox33.Text = "STANDBY";
            this.checkBox33.UseVisualStyleBackColor = true;
            this.checkBox33.CheckedChanged += new System.EventHandler(this.checkBox33_CheckedChanged);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.button1);
            this.groupBox12.Location = new System.Drawing.Point(288, 3);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(218, 60);
            this.groupBox12.TabIndex = 265;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Save Config";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(7, 19);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(200, 35);
            this.button1.TabIndex = 203;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // checkBox34
            // 
            this.checkBox34.AutoSize = true;
            this.checkBox34.ForeColor = System.Drawing.Color.Black;
            this.checkBox34.Location = new System.Drawing.Point(202, 24);
            this.checkBox34.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox34.Name = "checkBox34";
            this.checkBox34.Size = new System.Drawing.Size(63, 21);
            this.checkBox34.TabIndex = 260;
            this.checkBox34.Text = "RESET";
            this.checkBox34.UseVisualStyleBackColor = true;
            this.checkBox34.CheckedChanged += new System.EventHandler(this.checkBox34_CheckedChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.checkBox31);
            this.panel2.Controls.Add(this.groupBox5);
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Controls.Add(this.checkBox32);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Location = new System.Drawing.Point(7, 330);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(499, 288);
            this.panel2.TabIndex = 215;
            // 
            // checkBox31
            // 
            this.checkBox31.AutoSize = true;
            this.checkBox31.Location = new System.Drawing.Point(101, 8);
            this.checkBox31.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox31.Name = "checkBox31";
            this.checkBox31.Size = new System.Drawing.Size(38, 21);
            this.checkBox31.TabIndex = 221;
            this.checkBox31.Text = "In";
            this.checkBox31.UseVisualStyleBackColor = true;
            this.checkBox31.CheckedChanged += new System.EventHandler(this.checkBox31_CheckedChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.groupBox14);
            this.groupBox5.Controls.Add(this.groupBox8);
            this.groupBox5.Controls.Add(this.groupBox6);
            this.groupBox5.Controls.Add(this.groupBox7);
            this.groupBox5.Location = new System.Drawing.Point(260, 33);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(228, 248);
            this.groupBox5.TabIndex = 213;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Output Configure:";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.checkBox9);
            this.groupBox14.Controls.Add(this.checkBox10);
            this.groupBox14.Location = new System.Drawing.Point(13, 196);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(200, 48);
            this.groupBox14.TabIndex = 168;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Port Value:";
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(110, 17);
            this.checkBox9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(84, 21);
            this.checkBox9.TabIndex = 160;
            this.checkBox9.Text = "Low-Level";
            this.checkBox9.UseVisualStyleBackColor = true;
            this.checkBox9.CheckedChanged += new System.EventHandler(this.checkBox9_CheckedChanged);
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(8, 17);
            this.checkBox10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(88, 21);
            this.checkBox10.TabIndex = 161;
            this.checkBox10.Text = "High-Level";
            this.checkBox10.UseVisualStyleBackColor = true;
            this.checkBox10.CheckedChanged += new System.EventHandler(this.checkBox10_CheckedChanged);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.checkBox1);
            this.groupBox8.Controls.Add(this.checkBox2);
            this.groupBox8.Location = new System.Drawing.Point(13, 22);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(200, 50);
            this.groupBox8.TabIndex = 167;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Bidirectional Mode:";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(10, 20);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(47, 21);
            this.checkBox1.TabIndex = 157;
            this.checkBox1.Text = "Yes";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(110, 20);
            this.checkBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(45, 21);
            this.checkBox2.TabIndex = 156;
            this.checkBox2.Text = "No";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.checkBox5);
            this.groupBox6.Controls.Add(this.checkBox6);
            this.groupBox6.Location = new System.Drawing.Point(13, 142);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(200, 48);
            this.groupBox6.TabIndex = 166;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Output Mode:";
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(9, 18);
            this.checkBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(95, 21);
            this.checkBox5.TabIndex = 160;
            this.checkBox5.Text = "Open-Drain";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(110, 18);
            this.checkBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(79, 21);
            this.checkBox6.TabIndex = 161;
            this.checkBox6.Text = "Push-Pull";
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.checkBox3);
            this.groupBox7.Controls.Add(this.checkBox4);
            this.groupBox7.Location = new System.Drawing.Point(13, 83);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(200, 48);
            this.groupBox7.TabIndex = 165;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Driver Strength:";
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(110, 20);
            this.checkBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(66, 21);
            this.checkBox3.TabIndex = 153;
            this.checkBox3.Text = "10Mhz";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(10, 20);
            this.checkBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(66, 21);
            this.checkBox4.TabIndex = 154;
            this.checkBox4.Text = "40Mhz";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox15);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.groupBox2);
            this.groupBox3.Controls.Add(this.groupBox1);
            this.groupBox3.Location = new System.Drawing.Point(10, 33);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(228, 248);
            this.groupBox3.TabIndex = 212;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Input Configure:";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.label8);
            this.groupBox15.Location = new System.Drawing.Point(13, 196);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(200, 48);
            this.groupBox15.TabIndex = 214;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Port Value:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 25);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(117, 17);
            this.label8.TabIndex = 0;
            this.label8.Text = "Default : Low-Level";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.checkBox8);
            this.groupBox4.Controls.Add(this.checkBox7);
            this.groupBox4.Location = new System.Drawing.Point(13, 22);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(200, 50);
            this.groupBox4.TabIndex = 213;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Enable Input Buffer:";
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(94, 23);
            this.checkBox8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(70, 21);
            this.checkBox8.TabIndex = 147;
            this.checkBox8.Text = "Disable";
            this.checkBox8.UseVisualStyleBackColor = true;
            this.checkBox8.CheckedChanged += new System.EventHandler(this.checkBox8_CheckedChanged);
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(9, 23);
            this.checkBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(66, 21);
            this.checkBox7.TabIndex = 146;
            this.checkBox7.Text = "Enable";
            this.checkBox7.UseVisualStyleBackColor = true;
            this.checkBox7.CheckedChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkBox28);
            this.groupBox2.Controls.Add(this.checkBox27);
            this.groupBox2.Location = new System.Drawing.Point(13, 142);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 48);
            this.groupBox2.TabIndex = 166;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Internal Pull-down:";
            // 
            // checkBox28
            // 
            this.checkBox28.AutoSize = true;
            this.checkBox28.Location = new System.Drawing.Point(94, 18);
            this.checkBox28.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox28.Name = "checkBox28";
            this.checkBox28.Size = new System.Drawing.Size(45, 21);
            this.checkBox28.TabIndex = 141;
            this.checkBox28.Text = "No";
            this.checkBox28.UseVisualStyleBackColor = true;
            this.checkBox28.CheckedChanged += new System.EventHandler(this.checkBox28_CheckedChanged);
            // 
            // checkBox27
            // 
            this.checkBox27.AutoSize = true;
            this.checkBox27.Location = new System.Drawing.Point(9, 18);
            this.checkBox27.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox27.Name = "checkBox27";
            this.checkBox27.Size = new System.Drawing.Size(47, 21);
            this.checkBox27.TabIndex = 142;
            this.checkBox27.Text = "Yes";
            this.checkBox27.UseVisualStyleBackColor = true;
            this.checkBox27.CheckedChanged += new System.EventHandler(this.checkBox27_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox26);
            this.groupBox1.Controls.Add(this.checkBox25);
            this.groupBox1.Location = new System.Drawing.Point(13, 83);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 48);
            this.groupBox1.TabIndex = 165;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Internal Pull-up:";
            // 
            // checkBox26
            // 
            this.checkBox26.AutoSize = true;
            this.checkBox26.Location = new System.Drawing.Point(94, 20);
            this.checkBox26.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox26.Name = "checkBox26";
            this.checkBox26.Size = new System.Drawing.Size(45, 21);
            this.checkBox26.TabIndex = 144;
            this.checkBox26.Text = "No";
            this.checkBox26.UseVisualStyleBackColor = true;
            this.checkBox26.CheckedChanged += new System.EventHandler(this.checkBox26_CheckedChanged);
            // 
            // checkBox25
            // 
            this.checkBox25.AutoSize = true;
            this.checkBox25.Location = new System.Drawing.Point(9, 20);
            this.checkBox25.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(47, 21);
            this.checkBox25.TabIndex = 145;
            this.checkBox25.Text = "Yes";
            this.checkBox25.UseVisualStyleBackColor = true;
            this.checkBox25.CheckedChanged += new System.EventHandler(this.checkBox25_CheckedChanged);
            // 
            // checkBox32
            // 
            this.checkBox32.AutoSize = true;
            this.checkBox32.Location = new System.Drawing.Point(282, 9);
            this.checkBox32.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox32.Name = "checkBox32";
            this.checkBox32.Size = new System.Drawing.Size(48, 21);
            this.checkBox32.TabIndex = 220;
            this.checkBox32.Text = "Out";
            this.checkBox32.UseVisualStyleBackColor = true;
            this.checkBox32.CheckedChanged += new System.EventHandler(this.checkBox32_CheckedChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(30, 5);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(48, 17);
            this.label22.TabIndex = 219;
            this.label22.Text = "In/Out:";
            // 
            // checkBox35
            // 
            this.checkBox35.AutoSize = true;
            this.checkBox35.ForeColor = System.Drawing.Color.Black;
            this.checkBox35.Location = new System.Drawing.Point(202, 5);
            this.checkBox35.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox35.Name = "checkBox35";
            this.checkBox35.Size = new System.Drawing.Size(69, 21);
            this.checkBox35.TabIndex = 259;
            this.checkBox35.Text = "ACTIVE";
            this.checkBox35.UseVisualStyleBackColor = true;
            this.checkBox35.CheckedChanged += new System.EventHandler(this.checkBox35_CheckedChanged);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label31);
            this.groupBox9.Controls.Add(this.comboBox3);
            this.groupBox9.Controls.Add(this.groupBox11);
            this.groupBox9.Controls.Add(this.label13);
            this.groupBox9.Controls.Add(this.groupBox10);
            this.groupBox9.Controls.Add(this.comboBox2);
            this.groupBox9.Location = new System.Drawing.Point(7, 66);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(499, 263);
            this.groupBox9.TabIndex = 214;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Alternative Configure:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label31.Location = new System.Drawing.Point(304, 29);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(90, 17);
            this.label31.TabIndex = 220;
            this.label31.Text = "Add Interrupt:";
            // 
            // comboBox3
            // 
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.comboBox3.Location = new System.Drawing.Point(403, 26);
            this.comboBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(64, 25);
            this.comboBox3.TabIndex = 221;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.radioButton10);
            this.groupBox11.Controls.Add(this.label17);
            this.groupBox11.Controls.Add(this.radioButton2);
            this.groupBox11.Controls.Add(this.radioButton3);
            this.groupBox11.Controls.Add(this.radioButton4);
            this.groupBox11.Controls.Add(this.radioButton5);
            this.groupBox11.Controls.Add(this.label19);
            this.groupBox11.Controls.Add(this.label18);
            this.groupBox11.Controls.Add(this.label21);
            this.groupBox11.Controls.Add(this.label20);
            this.groupBox11.Controls.Add(this.textBox10);
            this.groupBox11.Controls.Add(this.textBox6);
            this.groupBox11.Controls.Add(this.textBox9);
            this.groupBox11.Controls.Add(this.textBox8);
            this.groupBox11.Controls.Add(this.textBox7);
            this.groupBox11.Location = new System.Drawing.Point(260, 56);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(228, 194);
            this.groupBox11.TabIndex = 217;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Output Function";
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(140, 158);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(14, 13);
            this.radioButton10.TabIndex = 38;
            this.radioButton10.TabStop = true;
            this.radioButton10.UseVisualStyleBackColor = true;
            this.radioButton10.CheckedChanged += new System.EventHandler(this.radioButton10_CheckedChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label17.Location = new System.Drawing.Point(6, 25);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(46, 17);
            this.label17.TabIndex = 38;
            this.label17.Text = "OUT_1";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(140, 123);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(14, 13);
            this.radioButton2.TabIndex = 30;
            this.radioButton2.TabStop = true;
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(140, 91);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(14, 13);
            this.radioButton3.TabIndex = 31;
            this.radioButton3.TabStop = true;
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(140, 59);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(14, 13);
            this.radioButton4.TabIndex = 32;
            this.radioButton4.TabStop = true;
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(140, 27);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(14, 13);
            this.radioButton5.TabIndex = 33;
            this.radioButton5.TabStop = true;
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label19.Location = new System.Drawing.Point(6, 89);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(46, 17);
            this.label19.TabIndex = 40;
            this.label19.Text = "OUT_3";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label18.Location = new System.Drawing.Point(6, 57);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(46, 17);
            this.label18.TabIndex = 39;
            this.label18.Text = "OUT_2";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.Location = new System.Drawing.Point(6, 153);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(46, 17);
            this.label21.TabIndex = 42;
            this.label21.Text = "OUT_5";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(6, 121);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(46, 17);
            this.label20.TabIndex = 41;
            this.label20.Text = "OUT_4";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(54, 22);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(80, 23);
            this.textBox10.TabIndex = 19;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(54, 150);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(80, 23);
            this.textBox6.TabIndex = 27;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(54, 54);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(80, 23);
            this.textBox9.TabIndex = 21;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(54, 86);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(80, 23);
            this.textBox8.TabIndex = 23;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(54, 118);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(80, 23);
            this.textBox7.TabIndex = 25;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.Location = new System.Drawing.Point(51, 32);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 17);
            this.label13.TabIndex = 203;
            this.label13.Text = "Direct Control:";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.textBox1);
            this.groupBox10.Controls.Add(this.radioButton6);
            this.groupBox10.Controls.Add(this.radioButton7);
            this.groupBox10.Controls.Add(this.radioButton8);
            this.groupBox10.Controls.Add(this.radioButton9);
            this.groupBox10.Controls.Add(this.label15);
            this.groupBox10.Controls.Add(this.radioButton1);
            this.groupBox10.Controls.Add(this.label2);
            this.groupBox10.Controls.Add(this.label4);
            this.groupBox10.Controls.Add(this.label5);
            this.groupBox10.Controls.Add(this.label6);
            this.groupBox10.Controls.Add(this.textBox2);
            this.groupBox10.Controls.Add(this.textBox3);
            this.groupBox10.Controls.Add(this.textBox4);
            this.groupBox10.Controls.Add(this.textBox5);
            this.groupBox10.Location = new System.Drawing.Point(9, 56);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(228, 194);
            this.groupBox10.TabIndex = 216;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Input Function";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(54, 27);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(80, 23);
            this.textBox1.TabIndex = 0;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(140, 159);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(14, 13);
            this.radioButton6.TabIndex = 34;
            this.radioButton6.TabStop = true;
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged);
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(140, 128);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(14, 13);
            this.radioButton7.TabIndex = 35;
            this.radioButton7.TabStop = true;
            this.radioButton7.UseVisualStyleBackColor = true;
            this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton7_CheckedChanged);
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(140, 96);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(14, 13);
            this.radioButton8.TabIndex = 36;
            this.radioButton8.TabStop = true;
            this.radioButton8.UseVisualStyleBackColor = true;
            this.radioButton8.CheckedChanged += new System.EventHandler(this.radioButton8_CheckedChanged);
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(140, 64);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(14, 13);
            this.radioButton9.TabIndex = 37;
            this.radioButton9.TabStop = true;
            this.radioButton9.UseVisualStyleBackColor = true;
            this.radioButton9.CheckedChanged += new System.EventHandler(this.radioButton9_CheckedChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(6, 30);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(34, 17);
            this.label15.TabIndex = 10;
            this.label15.Text = "IN_1";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(140, 30);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(14, 13);
            this.radioButton1.TabIndex = 29;
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(6, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 17);
            this.label2.TabIndex = 12;
            this.label2.Text = "IN_2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(6, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 17);
            this.label4.TabIndex = 14;
            this.label4.Text = "IN_3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(6, 126);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 17);
            this.label5.TabIndex = 16;
            this.label5.Text = "IN_4";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(6, 158);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 17);
            this.label6.TabIndex = 18;
            this.label6.Text = "IN_5";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(54, 59);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(80, 23);
            this.textBox2.TabIndex = 11;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(54, 91);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(80, 23);
            this.textBox3.TabIndex = 13;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(54, 123);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(80, 23);
            this.textBox4.TabIndex = 15;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(54, 155);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(80, 23);
            this.textBox5.TabIndex = 17;
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.comboBox2.Location = new System.Drawing.Point(149, 26);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(64, 25);
            this.comboBox2.TabIndex = 204;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "GPIO",
            "Alternative"});
            this.comboBox1.Location = new System.Drawing.Point(84, 35);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(98, 25);
            this.comboBox1.TabIndex = 207;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            this.comboBox1.TextChanged += new System.EventHandler(this.comboBox1_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(13, 38);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 17);
            this.label12.TabIndex = 206;
            this.label12.Text = "GPIO/ALT:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(14, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 17);
            this.label3.TabIndex = 204;
            this.label3.Text = "PORT:";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.ForeColor = System.Drawing.Color.Blue;
            this.label58.Location = new System.Drawing.Point(445, 35);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(45, 17);
            this.label58.TabIndex = 122;
            this.label58.Text = "ISOVC";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.ForeColor = System.Drawing.Color.Blue;
            this.label57.Location = new System.Drawing.Point(419, 54);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(44, 17);
            this.label57.TabIndex = 121;
            this.label57.Text = "ISOVS";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.ForeColor = System.Drawing.Color.Blue;
            this.label56.Location = new System.Drawing.Point(181, 54);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(39, 17);
            this.label56.TabIndex = 120;
            this.label56.Text = "EVCC";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.ForeColor = System.Drawing.Color.Blue;
            this.label55.Location = new System.Drawing.Point(158, 35);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(37, 17);
            this.label55.TabIndex = 119;
            this.label55.Text = "EVSS";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.ForeColor = System.Drawing.Color.Blue;
            this.label54.Location = new System.Drawing.Point(11, 386);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(39, 17);
            this.label54.TabIndex = 118;
            this.label54.Text = "EVCC";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.ForeColor = System.Drawing.Color.Blue;
            this.label53.Location = new System.Drawing.Point(304, 562);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(27, 17);
            this.label53.TabIndex = 117;
            this.label53.Text = "FL0";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.ForeColor = System.Drawing.Color.Blue;
            this.label52.Location = new System.Drawing.Point(261, 562);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(23, 17);
            this.label52.TabIndex = 116;
            this.label52.Text = "X1";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.ForeColor = System.Drawing.Color.Blue;
            this.label51.Location = new System.Drawing.Point(285, 543);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(23, 17);
            this.label51.TabIndex = 115;
            this.label51.Text = "X2";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.ForeColor = System.Drawing.Color.Blue;
            this.label50.Location = new System.Drawing.Point(232, 543);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(32, 17);
            this.label50.TabIndex = 114;
            this.label50.Text = "RVC";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.ForeColor = System.Drawing.Color.Blue;
            this.label49.Location = new System.Drawing.Point(184, 543);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(31, 17);
            this.label49.TabIndex = 113;
            this.label49.Text = "AVS";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.ForeColor = System.Drawing.Color.Blue;
            this.label44.Location = new System.Drawing.Point(209, 562);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(30, 17);
            this.label44.TabIndex = 112;
            this.label44.Text = "AVL";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.ForeColor = System.Drawing.Color.Blue;
            this.label30.Location = new System.Drawing.Point(156, 562);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(44, 17);
            this.label30.TabIndex = 111;
            this.label30.Text = "RESET";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Blue;
            this.label14.Location = new System.Drawing.Point(532, 456);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 17);
            this.label14.TabIndex = 110;
            this.label14.Text = "A0VERF";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(532, 481);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 17);
            this.label7.TabIndex = 109;
            this.label7.Text = "A0VSS";
            // 
            // linkLabel63
            // 
            this.linkLabel63.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel63.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel63.Location = new System.Drawing.Point(450, 560);
            this.linkLabel63.Name = "linkLabel63";
            this.linkLabel63.Size = new System.Drawing.Size(47, 19);
            this.linkLabel63.TabIndex = 108;
            this.linkLabel63.TabStop = true;
            this.linkLabel63.Text = "P8_6";
            this.linkLabel63.UseMnemonic = false;
            this.linkLabel63.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel63_LinkClicked);
            // 
            // linkLabel40
            // 
            this.linkLabel40.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel40.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel40.Location = new System.Drawing.Point(423, 543);
            this.linkLabel40.Name = "linkLabel40";
            this.linkLabel40.Size = new System.Drawing.Size(47, 19);
            this.linkLabel40.TabIndex = 107;
            this.linkLabel40.TabStop = true;
            this.linkLabel40.Text = "P8_5";
            this.linkLabel40.UseMnemonic = false;
            this.linkLabel40.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel40_LinkClicked);
            // 
            // linkLabel49
            // 
            this.linkLabel49.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel49.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel49.Location = new System.Drawing.Point(374, 543);
            this.linkLabel49.Name = "linkLabel49";
            this.linkLabel49.Size = new System.Drawing.Size(47, 19);
            this.linkLabel49.TabIndex = 106;
            this.linkLabel49.TabStop = true;
            this.linkLabel49.Text = "P8_3";
            this.linkLabel49.UseMnemonic = false;
            this.linkLabel49.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel49_LinkClicked);
            // 
            // linkLabel50
            // 
            this.linkLabel50.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel50.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel50.Location = new System.Drawing.Point(397, 562);
            this.linkLabel50.Name = "linkLabel50";
            this.linkLabel50.Size = new System.Drawing.Size(47, 19);
            this.linkLabel50.TabIndex = 105;
            this.linkLabel50.TabStop = true;
            this.linkLabel50.Text = "P8_4";
            this.linkLabel50.UseMnemonic = false;
            this.linkLabel50.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel50_LinkClicked);
            // 
            // linkLabel51
            // 
            this.linkLabel51.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel51.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel51.Location = new System.Drawing.Point(351, 562);
            this.linkLabel51.Name = "linkLabel51";
            this.linkLabel51.Size = new System.Drawing.Size(47, 19);
            this.linkLabel51.TabIndex = 104;
            this.linkLabel51.TabStop = true;
            this.linkLabel51.Text = "P8_1";
            this.linkLabel51.UseMnemonic = false;
            this.linkLabel51.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel51_LinkClicked);
            // 
            // linkLabel52
            // 
            this.linkLabel52.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel52.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel52.Location = new System.Drawing.Point(327, 543);
            this.linkLabel52.Name = "linkLabel52";
            this.linkLabel52.Size = new System.Drawing.Size(47, 19);
            this.linkLabel52.TabIndex = 103;
            this.linkLabel52.TabStop = true;
            this.linkLabel52.Text = "P8_0";
            this.linkLabel52.UseMnemonic = false;
            this.linkLabel52.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel52_LinkClicked);
            // 
            // linkLabel59
            // 
            this.linkLabel59.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel59.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel59.Location = new System.Drawing.Point(134, 543);
            this.linkLabel59.Name = "linkLabel59";
            this.linkLabel59.Size = new System.Drawing.Size(47, 19);
            this.linkLabel59.TabIndex = 96;
            this.linkLabel59.TabStop = true;
            this.linkLabel59.Text = "JP0_0";
            this.linkLabel59.UseMnemonic = false;
            this.linkLabel59.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel59_LinkClicked);
            // 
            // linkLabel60
            // 
            this.linkLabel60.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel60.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel60.Location = new System.Drawing.Point(82, 543);
            this.linkLabel60.Name = "linkLabel60";
            this.linkLabel60.Size = new System.Drawing.Size(47, 19);
            this.linkLabel60.TabIndex = 95;
            this.linkLabel60.TabStop = true;
            this.linkLabel60.Text = "JP0_2";
            this.linkLabel60.UseMnemonic = false;
            this.linkLabel60.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel60_LinkClicked);
            // 
            // linkLabel61
            // 
            this.linkLabel61.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel61.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel61.Location = new System.Drawing.Point(108, 562);
            this.linkLabel61.Name = "linkLabel61";
            this.linkLabel61.Size = new System.Drawing.Size(47, 19);
            this.linkLabel61.TabIndex = 94;
            this.linkLabel61.TabStop = true;
            this.linkLabel61.Text = "JP0_1";
            this.linkLabel61.UseMnemonic = false;
            this.linkLabel61.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel61_LinkClicked);
            // 
            // linkLabel47
            // 
            this.linkLabel47.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel47.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel47.Location = new System.Drawing.Point(396, 35);
            this.linkLabel47.Name = "linkLabel47";
            this.linkLabel47.Size = new System.Drawing.Size(47, 19);
            this.linkLabel47.TabIndex = 90;
            this.linkLabel47.TabStop = true;
            this.linkLabel47.Text = "P10_6";
            this.linkLabel47.UseMnemonic = false;
            this.linkLabel47.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel47_LinkClicked);
            // 
            // linkLabel66
            // 
            this.linkLabel66.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel66.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel66.Location = new System.Drawing.Point(371, 54);
            this.linkLabel66.Name = "linkLabel66";
            this.linkLabel66.Size = new System.Drawing.Size(47, 19);
            this.linkLabel66.TabIndex = 87;
            this.linkLabel66.TabStop = true;
            this.linkLabel66.Text = "P10_7";
            this.linkLabel66.UseMnemonic = false;
            this.linkLabel66.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel66_LinkClicked);
            // 
            // linkLabel34
            // 
            this.linkLabel34.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel34.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel34.Location = new System.Drawing.Point(348, 35);
            this.linkLabel34.Name = "linkLabel34";
            this.linkLabel34.Size = new System.Drawing.Size(47, 19);
            this.linkLabel34.TabIndex = 86;
            this.linkLabel34.TabStop = true;
            this.linkLabel34.Text = "P10_8";
            this.linkLabel34.UseMnemonic = false;
            this.linkLabel34.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel34_LinkClicked);
            // 
            // linkLabel35
            // 
            this.linkLabel35.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel35.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel35.Location = new System.Drawing.Point(304, 35);
            this.linkLabel35.Name = "linkLabel35";
            this.linkLabel35.Size = new System.Drawing.Size(61, 19);
            this.linkLabel35.TabIndex = 85;
            this.linkLabel35.TabStop = true;
            this.linkLabel35.Text = "P10_10";
            this.linkLabel35.UseMnemonic = false;
            this.linkLabel35.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel35_LinkClicked);
            // 
            // linkLabel36
            // 
            this.linkLabel36.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel36.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel36.Location = new System.Drawing.Point(252, 35);
            this.linkLabel36.Name = "linkLabel36";
            this.linkLabel36.Size = new System.Drawing.Size(48, 19);
            this.linkLabel36.TabIndex = 84;
            this.linkLabel36.TabStop = true;
            this.linkLabel36.Text = "P10_12";
            this.linkLabel36.UseMnemonic = false;
            this.linkLabel36.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel36_LinkClicked);
            // 
            // linkLabel37
            // 
            this.linkLabel37.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel37.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel37.Location = new System.Drawing.Point(278, 54);
            this.linkLabel37.Name = "linkLabel37";
            this.linkLabel37.Size = new System.Drawing.Size(48, 19);
            this.linkLabel37.TabIndex = 83;
            this.linkLabel37.TabStop = true;
            this.linkLabel37.Text = "P10_11";
            this.linkLabel37.UseMnemonic = false;
            this.linkLabel37.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel37_LinkClicked);
            // 
            // linkLabel38
            // 
            this.linkLabel38.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel38.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel38.Location = new System.Drawing.Point(325, 54);
            this.linkLabel38.Name = "linkLabel38";
            this.linkLabel38.Size = new System.Drawing.Size(47, 19);
            this.linkLabel38.TabIndex = 82;
            this.linkLabel38.TabStop = true;
            this.linkLabel38.Text = "P10_9";
            this.linkLabel38.UseMnemonic = false;
            this.linkLabel38.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel38_LinkClicked);
            // 
            // linkLabel39
            // 
            this.linkLabel39.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel39.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel39.Location = new System.Drawing.Point(227, 54);
            this.linkLabel39.Name = "linkLabel39";
            this.linkLabel39.Size = new System.Drawing.Size(54, 19);
            this.linkLabel39.TabIndex = 81;
            this.linkLabel39.TabStop = true;
            this.linkLabel39.Text = "P10_13";
            this.linkLabel39.UseMnemonic = false;
            this.linkLabel39.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel39_LinkClicked);
            // 
            // linkLabel46
            // 
            this.linkLabel46.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel46.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel46.Location = new System.Drawing.Point(203, 35);
            this.linkLabel46.Name = "linkLabel46";
            this.linkLabel46.Size = new System.Drawing.Size(56, 19);
            this.linkLabel46.TabIndex = 80;
            this.linkLabel46.TabStop = true;
            this.linkLabel46.Text = "P10_14";
            this.linkLabel46.UseMnemonic = false;
            this.linkLabel46.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel46_LinkClicked);
            // 
            // linkLabel44
            // 
            this.linkLabel44.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel44.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel44.Location = new System.Drawing.Point(107, 35);
            this.linkLabel44.Name = "linkLabel44";
            this.linkLabel44.Size = new System.Drawing.Size(47, 19);
            this.linkLabel44.TabIndex = 78;
            this.linkLabel44.TabStop = true;
            this.linkLabel44.Text = "P10_1";
            this.linkLabel44.UseMnemonic = false;
            this.linkLabel44.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel44_LinkClicked);
            // 
            // linkLabel43
            // 
            this.linkLabel43.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel43.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel43.Location = new System.Drawing.Point(133, 54);
            this.linkLabel43.Name = "linkLabel43";
            this.linkLabel43.Size = new System.Drawing.Size(47, 19);
            this.linkLabel43.TabIndex = 77;
            this.linkLabel43.TabStop = true;
            this.linkLabel43.Text = "P10_0";
            this.linkLabel43.UseMnemonic = false;
            this.linkLabel43.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel43_LinkClicked);
            // 
            // linkLabel33
            // 
            this.linkLabel33.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel33.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel33.Location = new System.Drawing.Point(82, 54);
            this.linkLabel33.Name = "linkLabel33";
            this.linkLabel33.Size = new System.Drawing.Size(47, 19);
            this.linkLabel33.TabIndex = 67;
            this.linkLabel33.TabStop = true;
            this.linkLabel33.Text = "P10_2";
            this.linkLabel33.UseMnemonic = false;
            this.linkLabel33.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel33_LinkClicked);
            // 
            // linkLabel17
            // 
            this.linkLabel17.AutoSize = true;
            this.linkLabel17.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel17.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel17.Location = new System.Drawing.Point(532, 215);
            this.linkLabel17.Name = "linkLabel17";
            this.linkLabel17.Size = new System.Drawing.Size(42, 17);
            this.linkLabel17.TabIndex = 66;
            this.linkLabel17.TabStop = true;
            this.linkLabel17.Text = "AP0_0";
            this.linkLabel17.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel17_LinkClicked);
            // 
            // linkLabel20
            // 
            this.linkLabel20.AutoSize = true;
            this.linkLabel20.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel20.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel20.Location = new System.Drawing.Point(532, 432);
            this.linkLabel20.Name = "linkLabel20";
            this.linkLabel20.Size = new System.Drawing.Size(42, 17);
            this.linkLabel20.TabIndex = 30;
            this.linkLabel20.TabStop = true;
            this.linkLabel20.Text = "AP0_9";
            this.linkLabel20.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel20_LinkClicked);
            // 
            // linkLabel21
            // 
            this.linkLabel21.AutoSize = true;
            this.linkLabel21.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel21.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel21.Location = new System.Drawing.Point(532, 408);
            this.linkLabel21.Name = "linkLabel21";
            this.linkLabel21.Size = new System.Drawing.Size(42, 17);
            this.linkLabel21.TabIndex = 29;
            this.linkLabel21.TabStop = true;
            this.linkLabel21.Text = "AP0_8";
            this.linkLabel21.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel21_LinkClicked);
            // 
            // linkLabel22
            // 
            this.linkLabel22.AutoSize = true;
            this.linkLabel22.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel22.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel22.Location = new System.Drawing.Point(532, 384);
            this.linkLabel22.Name = "linkLabel22";
            this.linkLabel22.Size = new System.Drawing.Size(42, 17);
            this.linkLabel22.TabIndex = 28;
            this.linkLabel22.TabStop = true;
            this.linkLabel22.Text = "AP0_7";
            this.linkLabel22.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel22_LinkClicked);
            // 
            // linkLabel23
            // 
            this.linkLabel23.AutoSize = true;
            this.linkLabel23.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel23.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel23.Location = new System.Drawing.Point(532, 360);
            this.linkLabel23.Name = "linkLabel23";
            this.linkLabel23.Size = new System.Drawing.Size(42, 17);
            this.linkLabel23.TabIndex = 27;
            this.linkLabel23.TabStop = true;
            this.linkLabel23.Text = "AP0_6";
            this.linkLabel23.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel23_LinkClicked);
            // 
            // linkLabel24
            // 
            this.linkLabel24.AutoSize = true;
            this.linkLabel24.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel24.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel24.Location = new System.Drawing.Point(532, 336);
            this.linkLabel24.Name = "linkLabel24";
            this.linkLabel24.Size = new System.Drawing.Size(42, 17);
            this.linkLabel24.TabIndex = 26;
            this.linkLabel24.TabStop = true;
            this.linkLabel24.Text = "AP0_5";
            this.linkLabel24.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel24_LinkClicked);
            // 
            // linkLabel25
            // 
            this.linkLabel25.AutoSize = true;
            this.linkLabel25.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel25.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel25.Location = new System.Drawing.Point(532, 311);
            this.linkLabel25.Name = "linkLabel25";
            this.linkLabel25.Size = new System.Drawing.Size(42, 17);
            this.linkLabel25.TabIndex = 25;
            this.linkLabel25.TabStop = true;
            this.linkLabel25.Text = "AP0_4";
            this.linkLabel25.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel25_LinkClicked);
            // 
            // linkLabel26
            // 
            this.linkLabel26.AutoSize = true;
            this.linkLabel26.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel26.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel26.Location = new System.Drawing.Point(532, 287);
            this.linkLabel26.Name = "linkLabel26";
            this.linkLabel26.Size = new System.Drawing.Size(42, 17);
            this.linkLabel26.TabIndex = 24;
            this.linkLabel26.TabStop = true;
            this.linkLabel26.Text = "AP0_3";
            this.linkLabel26.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel26_LinkClicked);
            // 
            // linkLabel27
            // 
            this.linkLabel27.AutoSize = true;
            this.linkLabel27.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel27.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel27.Location = new System.Drawing.Point(532, 263);
            this.linkLabel27.Name = "linkLabel27";
            this.linkLabel27.Size = new System.Drawing.Size(42, 17);
            this.linkLabel27.TabIndex = 23;
            this.linkLabel27.TabStop = true;
            this.linkLabel27.Text = "AP0_2";
            this.linkLabel27.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel27_LinkClicked);
            // 
            // linkLabel28
            // 
            this.linkLabel28.AutoSize = true;
            this.linkLabel28.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel28.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel28.Location = new System.Drawing.Point(532, 238);
            this.linkLabel28.Name = "linkLabel28";
            this.linkLabel28.Size = new System.Drawing.Size(42, 17);
            this.linkLabel28.TabIndex = 22;
            this.linkLabel28.TabStop = true;
            this.linkLabel28.Text = "AP0_1";
            this.linkLabel28.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel28_LinkClicked);
            // 
            // linkLabel29
            // 
            this.linkLabel29.AutoSize = true;
            this.linkLabel29.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel29.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel29.Location = new System.Drawing.Point(532, 191);
            this.linkLabel29.Name = "linkLabel29";
            this.linkLabel29.Size = new System.Drawing.Size(34, 17);
            this.linkLabel29.TabIndex = 21;
            this.linkLabel29.TabStop = true;
            this.linkLabel29.Text = "P9_0";
            this.linkLabel29.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel29_LinkClicked);
            // 
            // linkLabel30
            // 
            this.linkLabel30.AutoSize = true;
            this.linkLabel30.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel30.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel30.Location = new System.Drawing.Point(532, 168);
            this.linkLabel30.Name = "linkLabel30";
            this.linkLabel30.Size = new System.Drawing.Size(34, 17);
            this.linkLabel30.TabIndex = 20;
            this.linkLabel30.TabStop = true;
            this.linkLabel30.Text = "P9_1";
            this.linkLabel30.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel30_LinkClicked);
            // 
            // linkLabel31
            // 
            this.linkLabel31.AutoSize = true;
            this.linkLabel31.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel31.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel31.Location = new System.Drawing.Point(532, 143);
            this.linkLabel31.Name = "linkLabel31";
            this.linkLabel31.Size = new System.Drawing.Size(34, 17);
            this.linkLabel31.TabIndex = 19;
            this.linkLabel31.TabStop = true;
            this.linkLabel31.Text = "P9_2";
            this.linkLabel31.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel31_LinkClicked);
            // 
            // linkLabel32
            // 
            this.linkLabel32.AutoSize = true;
            this.linkLabel32.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel32.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel32.Location = new System.Drawing.Point(532, 118);
            this.linkLabel32.Name = "linkLabel32";
            this.linkLabel32.Size = new System.Drawing.Size(34, 17);
            this.linkLabel32.TabIndex = 18;
            this.linkLabel32.TabStop = true;
            this.linkLabel32.Text = "P9_3";
            this.linkLabel32.UseMnemonic = false;
            this.linkLabel32.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel32_LinkClicked);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(56, 76);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(470, 464);
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // linkLabel16
            // 
            this.linkLabel16.AutoSize = true;
            this.linkLabel16.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel16.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel16.Location = new System.Drawing.Point(12, 484);
            this.linkLabel16.Name = "linkLabel16";
            this.linkLabel16.Size = new System.Drawing.Size(39, 17);
            this.linkLabel16.TabIndex = 16;
            this.linkLabel16.TabStop = true;
            this.linkLabel16.Text = "JP0_3";
            this.linkLabel16.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel16_LinkClicked);
            // 
            // linkLabel15
            // 
            this.linkLabel15.AutoSize = true;
            this.linkLabel15.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel15.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel15.Location = new System.Drawing.Point(12, 460);
            this.linkLabel15.Name = "linkLabel15";
            this.linkLabel15.Size = new System.Drawing.Size(39, 17);
            this.linkLabel15.TabIndex = 15;
            this.linkLabel15.TabStop = true;
            this.linkLabel15.Text = "JP0_4";
            this.linkLabel15.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel15_LinkClicked);
            // 
            // linkLabel14
            // 
            this.linkLabel14.AutoSize = true;
            this.linkLabel14.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel14.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel14.Location = new System.Drawing.Point(12, 435);
            this.linkLabel14.Name = "linkLabel14";
            this.linkLabel14.Size = new System.Drawing.Size(39, 17);
            this.linkLabel14.TabIndex = 14;
            this.linkLabel14.TabStop = true;
            this.linkLabel14.Text = "JP0_5";
            this.linkLabel14.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel14_LinkClicked);
            // 
            // linkLabel13
            // 
            this.linkLabel13.AutoSize = true;
            this.linkLabel13.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel13.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel13.Location = new System.Drawing.Point(12, 411);
            this.linkLabel13.Name = "linkLabel13";
            this.linkLabel13.Size = new System.Drawing.Size(34, 17);
            this.linkLabel13.TabIndex = 13;
            this.linkLabel13.TabStop = true;
            this.linkLabel13.Text = "P8_2";
            this.linkLabel13.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel13_LinkClicked);
            // 
            // linkLabel11
            // 
            this.linkLabel11.AutoSize = true;
            this.linkLabel11.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel11.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel11.Location = new System.Drawing.Point(12, 363);
            this.linkLabel11.Name = "linkLabel11";
            this.linkLabel11.Size = new System.Drawing.Size(34, 17);
            this.linkLabel11.TabIndex = 11;
            this.linkLabel11.TabStop = true;
            this.linkLabel11.Text = "P0_6";
            this.linkLabel11.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel11_LinkClicked);
            // 
            // linkLabel10
            // 
            this.linkLabel10.AutoSize = true;
            this.linkLabel10.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel10.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel10.Location = new System.Drawing.Point(12, 339);
            this.linkLabel10.Name = "linkLabel10";
            this.linkLabel10.Size = new System.Drawing.Size(34, 17);
            this.linkLabel10.TabIndex = 10;
            this.linkLabel10.TabStop = true;
            this.linkLabel10.Text = "P0_5";
            this.linkLabel10.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel10_LinkClicked);
            // 
            // linkLabel9
            // 
            this.linkLabel9.AutoSize = true;
            this.linkLabel9.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel9.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel9.Location = new System.Drawing.Point(12, 315);
            this.linkLabel9.Name = "linkLabel9";
            this.linkLabel9.Size = new System.Drawing.Size(34, 17);
            this.linkLabel9.TabIndex = 9;
            this.linkLabel9.TabStop = true;
            this.linkLabel9.Text = "P0_4";
            this.linkLabel9.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel9_LinkClicked);
            // 
            // linkLabel8
            // 
            this.linkLabel8.AutoSize = true;
            this.linkLabel8.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel8.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel8.Location = new System.Drawing.Point(12, 290);
            this.linkLabel8.Name = "linkLabel8";
            this.linkLabel8.Size = new System.Drawing.Size(39, 17);
            this.linkLabel8.TabIndex = 8;
            this.linkLabel8.TabStop = true;
            this.linkLabel8.Text = "EVCC";
            // 
            // linkLabel7
            // 
            this.linkLabel7.AutoSize = true;
            this.linkLabel7.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel7.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel7.Location = new System.Drawing.Point(12, 266);
            this.linkLabel7.Name = "linkLabel7";
            this.linkLabel7.Size = new System.Drawing.Size(34, 17);
            this.linkLabel7.TabIndex = 7;
            this.linkLabel7.TabStop = true;
            this.linkLabel7.Text = "P0_3";
            this.linkLabel7.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel7_LinkClicked);
            // 
            // linkLabel6
            // 
            this.linkLabel6.AutoSize = true;
            this.linkLabel6.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel6.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel6.Location = new System.Drawing.Point(12, 242);
            this.linkLabel6.Name = "linkLabel6";
            this.linkLabel6.Size = new System.Drawing.Size(34, 17);
            this.linkLabel6.TabIndex = 6;
            this.linkLabel6.TabStop = true;
            this.linkLabel6.Text = "P0_2";
            this.linkLabel6.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel6_LinkClicked);
            // 
            // linkLabel5
            // 
            this.linkLabel5.AutoSize = true;
            this.linkLabel5.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel5.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel5.Location = new System.Drawing.Point(12, 217);
            this.linkLabel5.Name = "linkLabel5";
            this.linkLabel5.Size = new System.Drawing.Size(34, 17);
            this.linkLabel5.TabIndex = 5;
            this.linkLabel5.TabStop = true;
            this.linkLabel5.Text = "P0_1";
            this.linkLabel5.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel5_LinkClicked);
            // 
            // linkLabel4
            // 
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel4.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel4.Location = new System.Drawing.Point(12, 193);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(34, 17);
            this.linkLabel4.TabIndex = 4;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "P0_0";
            this.linkLabel4.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel4_LinkClicked);
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel3.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel3.Location = new System.Drawing.Point(12, 170);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(41, 17);
            this.linkLabel3.TabIndex = 3;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "P10_5";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel2.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel2.Location = new System.Drawing.Point(12, 145);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(41, 17);
            this.linkLabel2.TabIndex = 2;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "P10_4";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel1.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel1.Location = new System.Drawing.Point(12, 120);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(41, 17);
            this.linkLabel1.TabIndex = 1;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "P10_3";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(129, 26);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(128, 22);
            this.toolStripMenuItem1.Text = "REMOVE";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1194, 778);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "64Pin Configure";
            this.Load += new System.EventHandler(this.Form2_Load_1);
            this.tabPage3.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.LinkLabel linkLabel16;
        private System.Windows.Forms.LinkLabel linkLabel15;
        private System.Windows.Forms.LinkLabel linkLabel14;
        private System.Windows.Forms.LinkLabel linkLabel13;
        private System.Windows.Forms.LinkLabel linkLabel11;
        private System.Windows.Forms.LinkLabel linkLabel10;
        private System.Windows.Forms.LinkLabel linkLabel9;
        private System.Windows.Forms.LinkLabel linkLabel8;
        private System.Windows.Forms.LinkLabel linkLabel7;
        private System.Windows.Forms.LinkLabel linkLabel6;
        private System.Windows.Forms.LinkLabel linkLabel5;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel linkLabel44;
        private System.Windows.Forms.LinkLabel linkLabel43;
        private System.Windows.Forms.LinkLabel linkLabel33;
        private System.Windows.Forms.LinkLabel linkLabel17;
        private System.Windows.Forms.LinkLabel linkLabel20;
        private System.Windows.Forms.LinkLabel linkLabel21;
        private System.Windows.Forms.LinkLabel linkLabel22;
        private System.Windows.Forms.LinkLabel linkLabel23;
        private System.Windows.Forms.LinkLabel linkLabel24;
        private System.Windows.Forms.LinkLabel linkLabel25;
        private System.Windows.Forms.LinkLabel linkLabel26;
        private System.Windows.Forms.LinkLabel linkLabel27;
        private System.Windows.Forms.LinkLabel linkLabel28;
        private System.Windows.Forms.LinkLabel linkLabel29;
        private System.Windows.Forms.LinkLabel linkLabel30;
        private System.Windows.Forms.LinkLabel linkLabel31;
        private System.Windows.Forms.LinkLabel linkLabel32;
        private System.Windows.Forms.LinkLabel linkLabel63;
        private System.Windows.Forms.LinkLabel linkLabel40;
        private System.Windows.Forms.LinkLabel linkLabel49;
        private System.Windows.Forms.LinkLabel linkLabel50;
        private System.Windows.Forms.LinkLabel linkLabel51;
        private System.Windows.Forms.LinkLabel linkLabel52;
        private System.Windows.Forms.LinkLabel linkLabel59;
        private System.Windows.Forms.LinkLabel linkLabel60;
        private System.Windows.Forms.LinkLabel linkLabel61;
        private System.Windows.Forms.LinkLabel linkLabel47;
        private System.Windows.Forms.LinkLabel linkLabel66;
        private System.Windows.Forms.LinkLabel linkLabel34;
        private System.Windows.Forms.LinkLabel linkLabel35;
        private System.Windows.Forms.LinkLabel linkLabel36;
        private System.Windows.Forms.LinkLabel linkLabel37;
        private System.Windows.Forms.LinkLabel linkLabel38;
        private System.Windows.Forms.LinkLabel linkLabel39;
        private System.Windows.Forms.LinkLabel linkLabel46;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox checkBox33;
        private System.Windows.Forms.CheckBox checkBox34;
        private System.Windows.Forms.CheckBox checkBox35;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox checkBox28;
        private System.Windows.Forms.CheckBox checkBox27;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox26;
        private System.Windows.Forms.CheckBox checkBox25;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox checkBox31;
        private System.Windows.Forms.CheckBox checkBox32;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.ComboBox comboBox15;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.ComboBox comboBox16;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.ColumnHeader columnHeader21;
        private System.Windows.Forms.ColumnHeader columnHeader22;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Label label8;
        public System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        public System.Windows.Forms.TextBox textBox22;
        public System.Windows.Forms.TextBox textBox14;
        public System.Windows.Forms.TextBox textBox13;
        public System.Windows.Forms.TextBox textBox12;
        public System.Windows.Forms.TextBox textBox21;
        public System.Windows.Forms.TextBox textBox20;
        public System.Windows.Forms.TextBox textBox19;
        public System.Windows.Forms.TextBox textBox18;
        public System.Windows.Forms.TextBox textBox17;
        public System.Windows.Forms.TextBox textBox16;
        public System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader23;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.LinkLabel linkLabel12;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.LinkLabel linkLabel84;
        private System.Windows.Forms.Label label32;


    }
}