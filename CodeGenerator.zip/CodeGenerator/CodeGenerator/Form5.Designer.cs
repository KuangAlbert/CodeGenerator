﻿namespace CodeGenerator
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.label80 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label65 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.label64 = new System.Windows.Forms.Label();
            this.listView4 = new System.Windows.Forms.ListView();
            this.columnHeader25 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label79 = new System.Windows.Forms.Label();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.label61 = new System.Windows.Forms.Label();
            this.listView3 = new System.Windows.Forms.ListView();
            this.columnHeader24 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label63 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.label62 = new System.Windows.Forms.Label();
            this.linkLabel83 = new System.Windows.Forms.LinkLabel();
            this.label72 = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.label68 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.groupBox19.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox19
            // 
            this.groupBox19.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox19.Controls.Add(this.groupBox22);
            this.groupBox19.Controls.Add(this.groupBox21);
            this.groupBox19.Controls.Add(this.groupBox20);
            this.groupBox19.Controls.Add(this.pictureBox2);
            this.groupBox19.Controls.Add(this.pictureBox3);
            this.groupBox19.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox19.Location = new System.Drawing.Point(12, 12);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(1158, 362);
            this.groupBox19.TabIndex = 8;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Three-step System Initialization  ";
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.label80);
            this.groupBox22.Controls.Add(this.comboBox4);
            this.groupBox22.Controls.Add(this.label65);
            this.groupBox22.Controls.Add(this.button6);
            this.groupBox22.Controls.Add(this.label64);
            this.groupBox22.Controls.Add(this.listView4);
            this.groupBox22.Controls.Add(this.label79);
            this.groupBox22.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox22.Location = new System.Drawing.Point(860, 40);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(283, 283);
            this.groupBox22.TabIndex = 33;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "Step 3";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label80.Location = new System.Drawing.Point(135, 65);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(120, 40);
            this.label80.TabIndex = 347;
            this.label80.Text = "Peripheral Value\r\n       Selection";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(6, 63);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(84, 27);
            this.comboBox4.TabIndex = 6;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label65.Location = new System.Drawing.Point(111, 119);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(163, 20);
            this.label65.TabIndex = 346;
            this.label65.Text = "Save Peripheral Button";
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button6.Location = new System.Drawing.Point(6, 115);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(84, 28);
            this.button6.TabIndex = 345;
            this.button6.Text = "SAVE";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label64.Location = new System.Drawing.Point(121, 203);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(153, 40);
            this.label64.TabIndex = 344;
            this.label64.Text = "   Show Peripheral\r\nConfiguration Details";
            // 
            // listView4
            // 
            this.listView4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.listView4.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader25});
            this.listView4.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.listView4.FullRowSelect = true;
            this.listView4.GridLines = true;
            this.listView4.HoverSelection = true;
            this.listView4.Location = new System.Drawing.Point(6, 179);
            this.listView4.Name = "listView4";
            this.listView4.Size = new System.Drawing.Size(84, 88);
            this.listView4.TabIndex = 343;
            this.listView4.UseCompatibleStateImageBehavior = false;
            this.listView4.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader25
            // 
            this.columnHeader25.Text = "Port";
            this.columnHeader25.Width = 84;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label79.Location = new System.Drawing.Point(58, 31);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(181, 19);
            this.label79.TabIndex = 31;
            this.label79.Text = "Peripheral Configuration";
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.label61);
            this.groupBox21.Controls.Add(this.listView3);
            this.groupBox21.Controls.Add(this.label63);
            this.groupBox21.Controls.Add(this.button4);
            this.groupBox21.Controls.Add(this.label62);
            this.groupBox21.Controls.Add(this.linkLabel83);
            this.groupBox21.Controls.Add(this.label72);
            this.groupBox21.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox21.Location = new System.Drawing.Point(435, 40);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(283, 283);
            this.groupBox21.TabIndex = 32;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "Step 2";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label61.Location = new System.Drawing.Point(103, 203);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(174, 40);
            this.label61.TabIndex = 343;
            this.label61.Text = "Show Pin Configuration \r\n              Details";
            // 
            // listView3
            // 
            this.listView3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.listView3.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader24});
            this.listView3.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.listView3.FullRowSelect = true;
            this.listView3.GridLines = true;
            this.listView3.HoverSelection = true;
            this.listView3.Location = new System.Drawing.Point(13, 179);
            this.listView3.Name = "listView3";
            this.listView3.Size = new System.Drawing.Size(84, 88);
            this.listView3.TabIndex = 342;
            this.listView3.UseCompatibleStateImageBehavior = false;
            this.listView3.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader24
            // 
            this.columnHeader24.Text = "Port";
            this.columnHeader24.Width = 84;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label63.Location = new System.Drawing.Point(133, 119);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(116, 20);
            this.label63.TabIndex = 35;
            this.label63.Text = "Save Pin Button";
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button4.Location = new System.Drawing.Point(13, 115);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(84, 28);
            this.button4.TabIndex = 6;
            this.button4.Text = "SAVE";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label62.Location = new System.Drawing.Point(133, 66);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(112, 20);
            this.label62.TabIndex = 34;
            this.label62.Text = "Click Configure";
            // 
            // linkLabel83
            // 
            this.linkLabel83.AutoSize = true;
            this.linkLabel83.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.linkLabel83.LinkColor = System.Drawing.Color.Blue;
            this.linkLabel83.Location = new System.Drawing.Point(31, 66);
            this.linkLabel83.Name = "linkLabel83";
            this.linkLabel83.Size = new System.Drawing.Size(40, 20);
            this.linkLabel83.TabIndex = 32;
            this.linkLabel83.TabStop = true;
            this.linkLabel83.Text = "P0_0";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label72.Location = new System.Drawing.Point(66, 31);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(132, 19);
            this.label72.TabIndex = 31;
            this.label72.Text = "Pin Configuration";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.label68);
            this.groupBox20.Controls.Add(this.label66);
            this.groupBox20.Controls.Add(this.label78);
            this.groupBox20.Controls.Add(this.label75);
            this.groupBox20.Controls.Add(this.label76);
            this.groupBox20.Controls.Add(this.label73);
            this.groupBox20.Controls.Add(this.label71);
            this.groupBox20.Controls.Add(this.label74);
            this.groupBox20.Controls.Add(this.label69);
            this.groupBox20.Controls.Add(this.label70);
            this.groupBox20.Controls.Add(this.label67);
            this.groupBox20.Controls.Add(this.label60);
            this.groupBox20.Controls.Add(this.label77);
            this.groupBox20.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox20.Location = new System.Drawing.Point(11, 40);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(283, 283);
            this.groupBox20.TabIndex = 12;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Step 1";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label68.Location = new System.Drawing.Point(177, 223);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(36, 20);
            this.label68.TabIndex = 39;
            this.label68.Text = "KHz";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label66.Location = new System.Drawing.Point(177, 179);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(36, 20);
            this.label66.TabIndex = 38;
            this.label66.Text = "KHz";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label78.Location = new System.Drawing.Point(177, 131);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(41, 20);
            this.label78.TabIndex = 37;
            this.label78.Text = "MHz";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label75.Location = new System.Drawing.Point(95, 179);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(80, 20);
            this.label75.TabIndex = 36;
            this.label75.Text = " CLK  -   80";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label76.Location = new System.Drawing.Point(31, 179);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(47, 20);
            this.label76.TabIndex = 35;
            this.label76.Text = "PLL  : ";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label73.Location = new System.Drawing.Point(95, 131);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(76, 20);
            this.label73.TabIndex = 34;
            this.label73.Text = " CLK  -    8";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label71.Location = new System.Drawing.Point(26, 223);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(52, 20);
            this.label71.TabIndex = 31;
            this.label71.Text = "CUP  : ";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label74.Location = new System.Drawing.Point(31, 131);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(47, 20);
            this.label74.TabIndex = 33;
            this.label74.Text = "HSI  : ";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label69.Location = new System.Drawing.Point(95, 223);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(84, 20);
            this.label69.TabIndex = 32;
            this.label69.Text = " CLK  -  240";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label70.Location = new System.Drawing.Point(8, 31);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(256, 19);
            this.label70.TabIndex = 30;
            this.label70.Text = "Initial configuration after power on";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label67.Location = new System.Drawing.Point(95, 85);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(84, 20);
            this.label67.TabIndex = 16;
            this.label67.Text = " CLK  -  240";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label60.Location = new System.Drawing.Point(35, 85);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(43, 20);
            this.label60.TabIndex = 0;
            this.label60.Text = "LSI  : ";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label77.Location = new System.Drawing.Point(177, 85);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(36, 20);
            this.label77.TabIndex = 26;
            this.label77.Text = "KHz";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(293, 125);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(149, 121);
            this.pictureBox2.TabIndex = 35;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(718, 125);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(149, 121);
            this.pictureBox3.TabIndex = 36;
            this.pictureBox3.TabStop = false;
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1183, 379);
            this.Controls.Add(this.groupBox19);
            this.Name = "Form5";
            this.Text = "Config Step";
            this.groupBox19.ResumeLayout(false);
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.ListView listView4;
        private System.Windows.Forms.ColumnHeader columnHeader25;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.ListView listView3;
        private System.Windows.Forms.ColumnHeader columnHeader24;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.LinkLabel linkLabel83;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;

    }
}